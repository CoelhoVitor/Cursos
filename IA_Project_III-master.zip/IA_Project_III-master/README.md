# How to run

Go to project directory and run the commands below:
## Windows
```
python -m venv ./venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Linux
```
virtualenv venv
. ./venv/bin/activate
pip install -r requirements.txt
```

# Como executar

Vá para o diretório do projeto e execute os comandos abaixo:
## Windows
```
python -m venv ./venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Linux
```
virtualenv venv
. ./venv/bin/activate
pip install -r requirements.txt
```