import data

initial_candidates = []
final_candidates = []
chosed_candidates = []


def set_params(role, language, deep, experience, price, pace):
    if role != '(Sem escolha)':
        data.job_role.remove(role)
        data.job_role.append(role)

    if language != '(Sem escolha)':
        data.languages.remove(language)
        data.languages.append(language)

    if deep != '(Sem escolha)':
        data.language_deepening.remove(deep)
        data.language_deepening.append(deep)

    if experience != '(Sem escolha)':
        data.professional_experience.remove(experience)
        data.professional_experience.append(experience)

    if price != '(Sem escolha)':
        data.work_price.remove(price)
        data.work_price.append(price)

    if pace != '(Sem escolha)':
        data.work_pace.remove(pace)
        data.work_pace.append(pace)

    return True


def info_ind(individual):
    informations = []

    # ind[0] == job_role
    if individual[0] == 0:
        informations.append(data.job_role[0])
    elif individual[0] == 1:
        informations.append(data.job_role[1])
    elif individual[0] == 2:
        informations.append(data.job_role[2])

    # ind[1] == languages
    if individual[1] == 0:
        informations.append(data.languages[0])
    elif individual[1] == 1:
        informations.append(data.languages[1])
    elif individual[1] == 2:
        informations.append(data.languages[2])

    # ind[2] == language_deepening
    if individual[2] == 0:
        informations.append(data.language_deepening[0])
    elif individual[2] == 1:
        informations.append(data.language_deepening[1])
    elif individual[2] == 2:
        informations.append(data.language_deepening[2])

    # ind[3] == professional_experience
    if individual[3] == 0:
        informations.append(data.professional_experience[0])
    elif individual[3] == 1:
        informations.append(data.professional_experience[1])
    elif individual[3] == 2:
        informations.append(data.professional_experience[2])

    # ind[4] == work_price
    if individual[4] == 0:
        informations.append(data.work_price[0])
    elif individual[4] == 1:
        informations.append(data.work_price[1])
    elif individual[4] == 2:
        informations.append(data.work_price[2])

    # ind[5] == work_pace
    if individual[5] == 0:
        informations.append(data.work_pace[0])
    elif individual[5] == 1:
        informations.append(data.work_pace[1])
    elif individual[5] == 2:
        informations.append(data.work_pace[2])

    return informations
