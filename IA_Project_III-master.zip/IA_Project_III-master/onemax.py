from deap import base, creator, tools
from matplotlib import pyplot as plt
import random
import utils

ATTRIBUTES_SIZE = 6
ATTRIBUTES_MAX_VALUE = [2, 2, 2, 2, 2, 2]
TEAM_SIZE = 30
EXPECTED_TEAM = 5


def evaluate_maximize(individual):
    sum_average_attributes = 0

    for i in range(ATTRIBUTES_SIZE):
        sum_average_attributes += individual[i] / ATTRIBUTES_MAX_VALUE[i]

    return sum_average_attributes / ATTRIBUTES_SIZE,


creator.create("FitnessMax", base.Fitness, weights=(1.0,))
creator.create("Individual", list, fitness=creator.FitnessMax)

toolbox = base.Toolbox()

toolbox.register("job_role", random.randint, 0, 2)
toolbox.register("languages", random.randint, 0, 2)
toolbox.register("language_deepening", random.randint, 0, 2)
toolbox.register("professional_experience", random.randint, 0, 2)
toolbox.register("work_price", random.randint, 0, 2)
toolbox.register("work_pace", random.randint, 0, 2)

toolbox.register("individual", tools.initCycle, creator.Individual,
                 (toolbox.job_role,
                  toolbox.languages,
                  toolbox.language_deepening,
                  toolbox.professional_experience,
                  toolbox.work_price,
                  toolbox.work_pace), 1)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

toolbox.register("evaluate", evaluate_maximize)

toolbox.register("mate", tools.cxTwoPoint)
toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
toolbox.register("selectTournament", tools.selTournament, tournsize=int(TEAM_SIZE*0.2))


def main():
    random.seed(random.randrange(0, 100))

    pop = toolbox.population(n=TEAM_SIZE)

    # CXPB is the probability with which two individuals are crossed
    #
    # MUTPB is the probability for mutating an individual
    CXPB, MUTPB = 0.5, 0.2

    print("Start of evolution")
    print()

    # Evaluate the entire population
    count = 0
    fitnesses = list(map(toolbox.evaluate, pop))

    generation = []
    table_max = []
    table_min = []
    table_avg = []

    for ind, fit in zip(pop, fitnesses):
        count += 1

        print("Candidate {}: {} {}".format(count, ind, fit))
        print(utils.info_ind(ind))
        print()

        utils.initial_candidates.append(utils.info_ind(ind))
        ind.fitness.values = fit
    print()

    print("  Evaluated %i individuals" % len(pop))
    print()

    fits = [ind.fitness.values[0] for ind in pop]

    # Save initial candidates
    generation.append(0)
    table_max.append(max(fits))
    table_min.append(min(fits))
    length = len(pop)
    mean = sum(fits) / length
    table_avg.append(mean)

    # Variable keeping track of the number of generations
    g = 0

    count_candidates = 0

    # Begin the evolution
    while count_candidates < EXPECTED_TEAM and g < 50:
        count_candidates = 0
        utils.chosed_candidates.clear()

        utils.final_candidates.clear()

        g += 1

        generation.append(g)

        print("-- Generation %i --" % g)
        print()

        # Select the next generation individuals
        offspring = toolbox.selectTournament(pop, len(pop))
        # Clone the selected individuals
        offspring = list(map(toolbox.clone, offspring))

        # Apply crossover and mutation on the offspring
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            # cross two individuals with probability CXPB
            if random.random() < CXPB:
                print("Crossover occurred")
                toolbox.mate(child1, child2)
                # fitness values of the children
                # must be recalculated later
                del child1.fitness.values
                del child2.fitness.values
        print()

        for mutant in offspring:
            # mutate an individual with probability MUTPB
            if random.random() < MUTPB:
                print("Mutation occurred")
                toolbox.mutate(mutant)
                del mutant.fitness.values
        print()

        # Evaluate the individuals with an invalid fitness
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        count = 0
        fitnesses = map(toolbox.evaluate, invalid_ind)

        for ind, fit in zip(invalid_ind, fitnesses):
            count += 1

            print("Candidate {}: {} {}".format(count, ind, fit))
            print(utils.info_ind(ind))
            print()

            utils.final_candidates.append(utils.info_ind(ind))
            ind.fitness.values = fit

            # Se o individuo for ótimo, ele será escolhido pro time
            if ind.fitness.values[0] >= 1:
                count_candidates += 1
                utils.chosed_candidates.append(count)
        print()

        print("  Evaluated %i individuals" % len(invalid_ind))
        print()

        # The population is entirely replaced by the offspring
        pop[:] = offspring

        # Gather all the fitnesses in one list and print the stats
        fits = [ind.fitness.values[0] for ind in pop]

        length = len(pop)
        mean = sum(fits) / length
        # sum2 = sum(x * x for x in fits)
        # std = abs(sum2 / length - mean ** 2) ** 0.5

        table_max.append(max(fits))
        table_min.append(min(fits))
        table_avg.append(mean)

        print("  Min %s" % min(fits))
        print("  Max %s" % max(fits))
        print("  Avg %s" % mean)
        print()

    print("-- End of (successful) evolution --")
    print()
    print(" Chosed Candidates: {}".format(utils.chosed_candidates))
    print()

    plt.plot(generation, table_max, 'g', label='Melhor Fitness')
    plt.plot(generation, table_avg, 'b', label='Fitness Médio')
    plt.plot(generation, table_min, 'r', label='Pior Fitness')

    plt.title('Genetic Algorithm')
    plt.xlabel('Generations')
    plt.ylabel('Fitness')
    plt.legend(loc='lower right')
    plt.show()


if __name__ == "__main__":
    main()
