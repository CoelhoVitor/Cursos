from PyQt5.QtWidgets import (QApplication, QComboBox, QDialog, QGridLayout, QMessageBox,
                             QLabel, QPushButton, QTextEdit, QLineEdit, QFormLayout)
from PyQt5.QtGui import QIntValidator
import onemax
import utils


class WidgetGallery(QDialog):
    def __init__(self, parent=None):
        super(WidgetGallery, self).__init__(parent)

        # QApplication.setStyle("fusion")
        self.originalPalette = QApplication.palette()

        # Team size
        self.team_size_label = QLabel("Quantidade inicial de candidatos:")
        self.team_size_line_edit = QLineEdit()

        # Expected team
        self.expected_label = QLabel("Tamanho esperado do time:")
        self.expected_line_edit = QLineEdit()

        self.onlyInt = QIntValidator()
        self.team_size_line_edit.setValidator(self.onlyInt)
        self.expected_line_edit.setValidator(self.onlyInt)

        # Job role
        self.role_label = QLabel("Cargo:")
        self.role_array = ["(Sem escolha)", "Júnior", "Pleno", "Sênior"]
        self.role_combo_box = QComboBox()
        self.role_combo_box.addItems(self.role_array)
        self.get_role_text("(Sem escolha)")
        self.role_combo_box.activated[str].connect(self.get_role_text)

        # Language
        self.language_label = QLabel("Linguagem:")
        self.language_array = ["(Sem escolha)", "C#", "Java", "Python"]
        self.language_combo_box = QComboBox()
        self.language_combo_box.addItems(self.language_array)
        self.get_language_text("(Sem escolha)")
        self.language_combo_box.activated[str].connect(self.get_language_text)

        # Language deepening
        self.deep_label = QLabel("Aprofundamento da Linguagem:")
        self.deep_array = ["(Sem escolha)", "Iniciante", "Intermediário", "Avançado"]
        self.deep_combo_box = QComboBox()
        self.deep_combo_box.addItems(self.deep_array)
        self.get_deep_text("(Sem escolha)")
        self.deep_combo_box.activated[str].connect(self.get_deep_text)

        # Language deepening
        self.deep_label = QLabel("Aprofundamento da Linguagem:")
        self.deep_array = ["(Sem escolha)", "Iniciante", "Intermediário", "Avançado"]
        self.deep_combo_box = QComboBox()
        self.deep_combo_box.addItems(self.deep_array)
        self.get_deep_text("(Sem escolha)")
        self.deep_combo_box.activated[str].connect(self.get_deep_text)

        # Professional
        self.experience_label = QLabel("Experiência profissional:")
        self.experience_array = ["(Sem escolha)", "Iniciante", "Intermediário", "Avançado"]
        self.experience_combo_box = QComboBox()
        self.experience_combo_box.addItems(self.experience_array)
        self.get_experience_text("(Sem escolha)")
        self.experience_combo_box.activated[str].connect(self.get_experience_text)

        # Work price
        self.price_label = QLabel("Preço:")
        self.price_array = ["(Sem escolha)", "Barato", "Médio", "Caro"]
        self.price_combo_box = QComboBox()
        self.price_combo_box.addItems(self.price_array)
        self.get_price_text("(Sem escolha)")
        self.price_combo_box.activated[str].connect(self.get_price_text)

        # Work pace
        self.pace_label = QLabel("Velocidade:")
        self.pace_array = ["(Sem escolha)", "Devagar", "Médio", "Rápido"]
        self.pace_combo_box = QComboBox()
        self.pace_combo_box.addItems(self.pace_array)
        self.get_pace_text("(Sem escolha)")
        self.pace_combo_box.activated[str].connect(self.get_pace_text)

        # Alocate button
        self.alocate_button = QPushButton("Alocar")
        self.alocate_button.setToolTip('Começar alocação')
        self.alocate_button.clicked.connect(self.alocate_button_click)

        # Log
        self.log_label = QLabel("Saída")
        self.log_textbox = QTextEdit(self)
        self.log_textbox.setReadOnly(True)

        top_layout = QFormLayout()
        top_layout.addRow(self.team_size_label, self.team_size_line_edit)
        top_layout.addRow(self.expected_label, self.expected_line_edit)
        top_layout.addRow(self.role_label, self.role_combo_box)
        top_layout.addRow(self.language_label, self.language_combo_box)
        top_layout.addRow(self.deep_label, self.deep_combo_box)
        top_layout.addRow(self.experience_label, self.experience_combo_box)
        top_layout.addRow(self.price_label, self.price_combo_box)
        top_layout.addRow(self.pace_label, self.pace_combo_box)

        main_layout = QGridLayout()
        main_layout.setSpacing(10)
        main_layout.addLayout(top_layout, 1, 0, 1, 3)
        main_layout.addWidget(self.alocate_button, 3, 0, 1, 3)
        main_layout.addWidget(self.log_label, 4, 0)
        main_layout.addWidget(self.log_textbox, 5, 0, 1, 3)
        main_layout.setRowStretch(1, 1)
        main_layout.setRowStretch(2, 1)
        main_layout.setColumnStretch(0, 1)
        main_layout.setColumnStretch(1, 1)
        self.setLayout(main_layout)

        self.setWindowTitle("Trabalho para Alocação de Pessoas em um Projeto")

    def get_team_size_text(self, text):
        self.team_size_text = text

    def get_expected_text(self, text):
        self.expected_text = text

    def get_role_text(self, text):
        self.role_text = text

    def get_language_text(self, text):
        self.language_text = text

    def get_deep_text(self, text):
        self.deep_text = text

    def get_experience_text(self, text):
        self.experience_text = text

    def get_price_text(self, text):
        self.price_text = text

    def get_pace_text(self, text):
        self.pace_text = text

    def alocate_button_click(self):
        try:
            self.log_textbox.append('Selecionado: ')
            self.log_textbox.append('Cargo: ' + self.role_text)
            self.log_textbox.append('Linguagem: ' + self.language_text)
            self.log_textbox.append('Aprofundamento da Linguagem: ' + self.deep_text)
            self.log_textbox.append('Experiência profissional: ' + self.experience_text)
            self.log_textbox.append('Preço: ' + self.price_text)
            self.log_textbox.append('Velocidade: ' + self.pace_text)
            self.log_textbox.append('')
        except Exception as e:
            QMessageBox.critical(self, 'Erro', "Algo deu errado, por favor tente novamente. ", QMessageBox.Ok)
        else:
            onemax.TEAM_SIZE = int(self.team_size_line_edit.text())
            onemax.EXPECTED_TEAM = int(self.expected_line_edit.text())
            utils.set_params(self.role_text, self.language_text, self.deep_text, self.experience_text,
                             self.price_text, self.pace_text)
            onemax.main()

            self.log_textbox.append('Candidato(s) Inicial(ais): ')
            for i in range(len(utils.initial_candidates)):
                self.log_textbox.append('%i' % (i + 1))
                self.log_textbox.append('Cargo: ' + utils.initial_candidates[i][0])
                self.log_textbox.append('Linguagem: ' + utils.initial_candidates[i][1])
                self.log_textbox.append('Aprofundamento da Linguagem: ' + utils.initial_candidates[i][2])
                self.log_textbox.append('Experiência profissional: ' + utils.initial_candidates[i][3])
                self.log_textbox.append('Preço: ' + utils.initial_candidates[i][4])
                self.log_textbox.append('Velocidade: ' + utils.initial_candidates[i][5])
                self.log_textbox.append('')

            self.log_textbox.append('Candidato(s) Final(ais): ')
            for i in range(len(utils.final_candidates)):
                self.log_textbox.append('%i' % (i + 1))
                self.log_textbox.append('Cargo: ' + utils.final_candidates[i][0])
                self.log_textbox.append('Linguagem: ' + utils.final_candidates[i][1])
                self.log_textbox.append('Aprofundamento da Linguagem: ' + utils.final_candidates[i][2])
                self.log_textbox.append('Experiência profissional: ' + utils.final_candidates[i][3])
                self.log_textbox.append('Preço: ' + utils.final_candidates[i][4])
                self.log_textbox.append('Velocidade: ' + utils.final_candidates[i][5])
                self.log_textbox.append('')

            self.log_textbox.append('Candidato(s) Escolhido(s): ')
            for i in range(len(utils.chosed_candidates)):
                self.log_textbox.append('{}'.format(utils.chosed_candidates[i]))


if __name__ == '__main__':

    import sys

    app = QApplication(sys.argv)
    gallery = WidgetGallery()
    gallery.show()
    sys.exit(app.exec_())
